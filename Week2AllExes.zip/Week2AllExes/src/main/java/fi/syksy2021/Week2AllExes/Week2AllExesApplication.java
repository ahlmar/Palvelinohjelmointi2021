package fi.syksy2021.Week2AllExes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week2AllExesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week2AllExesApplication.class, args);
	}

}
