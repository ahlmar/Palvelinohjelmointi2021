package fi.syksy2021.Week2AllExes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2AllExesApplicationTests {

	@Test
	void contextLoads() {
	}

}
